"""
Buoc 1: chuan hoa lich tau PNC thanh du lieu dau vao cho mo hinh BACAP.

Doc  : data/pnc_schedule_raw.csv  (lay tu svc.pncport.com, Vessel Schedule (Text))
Ghi  : data/vessels_clean.csv

Cot quan trong trong file ket qua:
  etb, etd      : gio cap / gio roi theo ke hoach PNC
  berth_start_m : vi tri dau tau theo ke hoach PNC (quy doi tu so ben B4..B8)
  loa_m         : chieu dai tau (m)
  loa_source    : "web" = tra tren mang; "est" = uoc luong theo tuyen (can thay bang so that)
  W             : khoi luong lam hang (luot) = Dis + Load + Shift
  usable        : True neu du du lieu de dua vao mo hinh
"""
import math
import pandas as pd

# --- Thong so ben PNC -------------------------------------------------------
QUAY_LENGTH_M = 2000          # PNC: 5 ben, cau cang 2.000 m (DP World, Busan city)
BERTHS = ["B4", "B5", "B6", "B7", "B8"]
BERTH_LEN_M = QUAY_LENGTH_M / len(BERTHS)   # gia dinh 5 ben dai bang nhau: 400 m

# --- Chieu dai tau ------------------------------------------------------------
# LOA tra duoc tren mang (VesselFinder / MarineTraffic / Hafen Hamburg)
LOA_WEB = {
    "GERDA MAERSK": 367,
    "GUSTAV MAERSK": 366,
    "GUNVOR MAERSK": 367,
    "ANE MAERSK": 351,
}
# Uoc luong theo loai tuyen (GIA DINH, nen thay bang LOA that khi co)
SERVICE_CLASS_LOA = {
    # tuyen chinh xuyen Thai Binh Duong / A-Au: tau lon
    "GUSEC2E": 366, "GUSEC3": 366, "GUSWC2E": 366, "GUSWC4E": 366, "GUSWC5E": 366,
    "JADE": 366, "PHOENIX": 366, "AE19": 351, "AC3E": 367,
    # tuyen trung binh
    "CIX3": 300, "AC2S": 300, "ORIGAMI R": 300, "ORIENT E": 300, "GLX": 300,
    "ADD": 300, "KAGUYA": 300,
    # noi A / feeder
    "A14N": 200, "A14W": 200, "IA5N": 200, "IA88S": 200, "HP2": 200,
    "ANZL": 200, "A05": 200, "FI3W": 200,
}


def main():
    df = pd.read_csv("data/pnc_schedule_raw.csv")
    df["etb"] = pd.to_datetime(df["etb"])
    df["etd"] = pd.to_datetime(df["etd"])

    # vi tri ben theo ke hoach PNC
    df["berth_start_m"] = df["berth"].map(lambda b: BERTHS.index(b) * BERTH_LEN_M)

    # chieu dai tau
    def loa(row):
        if row["name"] in LOA_WEB:
            return LOA_WEB[row["name"]], "web"
        return SERVICE_CLASS_LOA.get(row["service"], 300), "est"
    df[["loa_m", "loa_source"]] = df.apply(lambda r: pd.Series(loa(r)), axis=1)

    # khoi luong lam hang
    notes = []
    for c in ["dis", "load", "shift"]:
        neg = df[c] < 0
        if neg.any():
            notes += [f"{n}: {c} am ({v}), dat = 0" for n, v in zip(df.loc[neg, "name"], df.loc[neg, c])]
            df.loc[neg, c] = 0
    df["W"] = df["dis"] + df["load"] + df["shift"]
    df["usable"] = df["W"] > 0
    for n in df.loc[~df["usable"], "name"]:
        notes.append(f"{n}: chua co khoi luong hang (W = 0), loai khoi mo hinh")

    # thong ke tham khao tu ke hoach PNC
    df["pnc_berth_hours"] = (df["etd"] - df["etb"]).dt.total_seconds() / 3600
    df["pnc_moves_per_hour"] = (df["W"] / df["pnc_berth_hours"]).round(1)

    df.to_csv("data/vessels_clean.csv", index=False)
    print(df[["code", "name", "berth", "etb", "loa_m", "loa_source", "W",
              "pnc_berth_hours", "pnc_moves_per_hour"]].to_string(index=False))
    print("\nGhi chu du lieu:")
    for n in notes:
        print(" -", n)
    print(f"\nNang suat ben trung binh theo ke hoach PNC: "
          f"{df.loc[df.usable, 'pnc_moves_per_hour'].median():.0f} luot/gio (trung vi)")


if __name__ == "__main__":
    main()
