"""
Chay mot case BACAP tren lich tau PNC.

Vi du:
  python run.py                                  # case mac dinh: 25/11 - 29/11/2026
  python run.py --start 2026-11-27 --days 3      # case khac
  python run.py --delta 50 --max-delay 12        # doi do dai unit, gio cho toi da

Ket qua trong thu muc output/:
  schedule_model_<case>.csv   lich do mo hinh xep
  schedule_model_<case>.png   bieu do lich (kieu PNC) + so cau dang dung
  schedule_pnc_<case>.png     ke hoach that cua PNC de so sanh
"""
import argparse
import math
import time

import pandas as pd

from bacap_milp import Params, build_and_solve, crane_range
from plot_schedule import plot


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--start", default="2026-11-25")
    ap.add_argument("--days", type=int, default=4)
    ap.add_argument("--delta", type=float, default=100)
    ap.add_argument("--rho", type=float, default=25)
    ap.add_argument("--Q", type=int, default=22)
    ap.add_argument("--max-delay", type=int, default=24)
    ap.add_argument("--step", type=int, default=2, help="do dai o thoi gian (gio)")
    ap.add_argument("--time-limit", type=float, default=120)
    args = ap.parse_args()

    p = Params(delta_m=args.delta, rho=args.rho, Q=args.Q,
               max_delay_h=args.max_delay, time_limit_s=args.time_limit, step_h=args.step)
    t0 = pd.Timestamp(args.start)
    t_end = t0 + pd.Timedelta(days=args.days)
    case = f"{t0:%m%d}_{args.days}d"

    df = pd.read_csv("data/vessels_clean.csv", parse_dates=["etb", "etd"])
    df = df[df["usable"]]

    # tau can xep lich: ETB nam trong cua so [t0, t_end)
    vessels = df[(df.etb >= t0) & (df.etb < t_end)].copy()
    # tau dang nam ben luc t0: giu nguyen vi tri va gio roi theo PNC
    fixed = df[(df.etb < t0) & (df.etd > t0)].copy()
    fixed["k_fixed"] = [
        min(max(crane_range(r.loa_m, p)), max(p.k_min, math.ceil(r.W / (p.rho * (r.etd - r.etb).total_seconds() / 3600))))
        for r in fixed.itertuples()
    ]

    print(f"Case {case}: {len(vessels)} tau can xep, {len(fixed)} tau dang nam ben luc {t0}")
    tic = time.time()
    sched, res, H = build_and_solve(vessels, fixed, t0, p)
    print(f"  Thoi gian giai: {time.time() - tic:.1f} giay")

    model = sched[~sched.fixed]
    model.to_csv(f"output/schedule_model_{case}.csv", index=False)

    # so sanh voi ke hoach PNC (ETB -> ETD)
    pnc = vessels.set_index("code")
    cmp = model.set_index("code")[["name", "k", "wait_h", "stay_h"]].copy()
    cmp["pnc_stay_h"] = ((pnc["etd"] - pnc["etb"]).dt.total_seconds() / 3600).round(1)
    print("\nSo sanh thoi gian o ben (gio): mo hinh vs ke hoach PNC")
    print(cmp.to_string())
    print(f"\nTong: mo hinh {cmp.stay_h.sum():.0f} gio | PNC {cmp.pnc_stay_h.sum():.0f} gio")

    t_plot_end = max(model["end"].max(), t_end)
    t_plot_end = t_plot_end.ceil("D")
    plot(sched, t0, t_plot_end, f"Lịch tàu do mô hình BACAP xếp — PNC, từ {t0:%d/%m/%Y} ({args.days} ngày)",
         f"output/schedule_model_{case}.png", quay_len=p.quay_length_m, Q=p.Q)

    # ve ke hoach that cua PNC cung kieu
    pv = pd.concat([fixed, vessels])
    pv = pv.assign(start=pv.etb, end=pv.etd, start_m=pv.berth_start_m,
                   end_m=pv.berth_start_m + pv.loa_m, fixed=pv.etb < t0,
                   k=[min(max(crane_range(r.loa_m, p)),
                          max(p.k_min, math.ceil(r.W / (p.rho * (r.etd - r.etb).total_seconds() / 3600))))
                      for r in pv.itertuples()])
    plot(pv, t0, t_plot_end, f"Kế hoạch thật của PNC — cùng khoảng thời gian (số cẩu là ước lượng)",
         f"output/schedule_pnc_{case}.png", quay_len=p.quay_length_m)
    print(f"\nDa luu hinh va CSV vao output/ (case {case})")


if __name__ == "__main__":
    main()
