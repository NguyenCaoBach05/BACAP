"""Kiem tra doc lap loi giai: khong chong lan, khong vuot Q, khong cap truoc gio den, nam gon tren cau cang."""
import sys
import pandas as pd

case = sys.argv[1] if len(sys.argv) > 1 else "1125_4d"
Q, L = 22, 2000
s = pd.read_csv(f"output/schedule_model_{case}.csv", parse_dates=["start", "end"])
v = pd.read_csv("data/vessels_clean.csv", parse_dates=["etb", "etd"]).set_index("code")
t0 = pd.Timestamp(f"2026-{case[:2]}-{case[2:4]}")
fixed = v[(v.etb < t0) & (v.etd > t0) & v.usable]
ok = True
for _, r in s.iterrows():
    if r.start < v.loc[r.code, "etb"].floor("h"):
        print("Cap truoc gio den:", r.code); ok = False
    if r.start_m < 0 or r.end_m > L:
        print("Nho ra ngoai cau cang:", r.code); ok = False
rows = s[["code", "start_m", "end_m", "start", "end"]].values.tolist()
for i in range(len(rows)):
    for j in range(i + 1, len(rows)):
        a, b = rows[i], rows[j]
        if a[1] < b[2] and b[1] < a[2] and a[3] < b[4] and b[3] < a[4]:
            print("Chong lan:", a[0], b[0]); ok = False
for h in pd.date_range(s.start.min(), s.end.max(), freq="h"):
    used = s[(s.start <= h) & (s.end > h)].k.sum()
    if used > Q:
        print("Vuot Q luc", h, used); ok = False
print("Tat ca rang buoc deu thoa." if ok else "CO VI PHAM.")
