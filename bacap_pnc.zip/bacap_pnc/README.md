# BACAP trên dữ liệu thật của PNC (Busan New Port)

Mô hình BACAP time-invariant (MILP) chạy trên lịch tàu PNC, rồi vẽ lịch theo kiểu
"Vessel Schedule (Graph)" của PNC để so với kế hoạch thật.

## 1. Cài đặt (một lần)

1. Cài **Python 3.10+** và **VS Code** (kèm extension *Python* của Microsoft).
2. Giải nén thư mục này, mở bằng VS Code: *File → Open Folder*.
3. Mở Terminal trong VS Code (*Ctrl + `*) rồi chạy:

```bash
python -m venv .venv
.venv\Scripts\activate          # Windows  (macOS/Linux: source .venv/bin/activate)
pip install -r requirements.txt
```

Không cần cài solver riêng: `scipy` đã có sẵn bộ giải **HiGHS** (`scipy.optimize.milp`).

## 2. Chạy

```bash
python prepare_data.py           # chuẩn hóa data/pnc_schedule_raw.csv -> data/vessels_clean.csv
python run.py                    # case mặc định: 25/11/2026, 4 ngày
python check_solution.py 1125_4d # kiểm tra lời giải độc lập
```

Kết quả nằm trong `output/`:

| File | Nội dung |
|---|---|
| `schedule_model_<case>.png` | Lịch do mô hình xếp, kèm biểu đồ số cẩu đang dùng so với Q |
| `schedule_pnc_<case>.png` | Kế hoạch thật của PNC, cùng kiểu vẽ để so sánh |
| `schedule_model_<case>.csv` | Lịch chi tiết: vị trí, giờ bắt đầu, số cẩu, thời gian chờ và ở bến |

Đổi case hoặc tham số:

```bash
python run.py --start 2026-11-27 --days 3
python run.py --step 1 --delta 50 --time-limit 600   # sát tài liệu hơn nhưng chậm hơn nhiều
python run.py --rho 30 --Q 20                         # phân tích độ nhạy
```

## 3. Dữ liệu và tham số

| Tham số | Giá trị | Nguồn |
|---|---|---|
| Chiều dài cầu cảng L | 2.000 m, 5 bến B4–B8 | DP World, Busan Metropolitan City |
| Số cẩu bờ Q | 22 | pncport.com, mục Equipment |
| Độ sâu | 17 m | pncport.com |
| Năng suất một cẩu ρ | 25 lượt/giờ | Giả định; khớp với năng suất bến trung vị 78 lượt/giờ trong kế hoạch PNC (khoảng 3 cẩu) |
| Lịch tàu, Dis/Load/Shift | 34 chuyến, 24/11–04/12/2026 | svc.pncport.com, Vessel Schedule (Text) |
| Chiều dài tàu LOA | 4 tàu tra trên mạng, còn lại ước lượng theo tuyến | Cột `loa_source`: `web` hoặc `est` |
| Số cẩu cho phép K_i | 2 đến min(6, LOA/60) | Giả định |
| Unit Δ, bước thời gian | 100 m, 2 giờ | Để mô hình giải được trong khoảng 30 giây |

Xử lý dữ liệu:
- `a_i` lấy bằng ETB của PNC (giờ sớm nhất được cập), vì lịch PNC không công bố giờ tàu đến neo.
- Tàu đang nằm bến lúc bắt đầu kế hoạch được giữ nguyên vị trí và giờ rời theo PNC.
- Tàu có khối lượng hàng bằng 0 (chưa khai báo) bị loại; giá trị Dis âm được đặt bằng 0.
- Bến B4–B8 quy đổi thành vị trí 0, 400, 800, 1.200, 1.600 m (giả định 5 bến dài bằng nhau).

**Nên cải thiện:** thay LOA ước lượng (`est`) trong `prepare_data.py` bằng LOA thật
(tra VesselFinder theo tên tàu), và hiệu chỉnh ρ nếu có số liệu năng suất cẩu của PNC.

## 4. Cấu trúc code

| File | Việc |
|---|---|
| `prepare_data.py` | Chuẩn hóa dữ liệu thô |
| `bacap_milp.py` | Mô hình: sinh phương án hợp lệ (ràng buộc 2, 3, 6), dựng ràng buộc (1), (4), (5), giải bằng HiGHS |
| `plot_schedule.py` | Vẽ lịch kiểu PNC |
| `run.py` | Chạy một case, so sánh với PNC |
| `check_solution.py` | Kiểm tra độc lập: không chồng lấn, không vượt Q, không cập trước giờ đến |
